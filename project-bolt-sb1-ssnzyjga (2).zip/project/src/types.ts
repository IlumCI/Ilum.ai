export interface Message {
  id: string;
  content: string;
  role: 'user' | 'assistant';
  timestamp: number;
}

export interface Settings {
  theme: 'light' | 'dark';
  fontSize: 'sm' | 'base' | 'lg';
  codeTheme: 'github' | 'dracula';
}

export interface ChatContextType {
  messages: Message[];
  settings: Settings;
  isLoading: boolean;
  error: string | null;
  addMessage: (content: string, role: Message['role']) => void;
  clearMessages: () => void;
  updateSettings: (settings: Partial<Settings>) => void;
  sendMessage: (content: string) => Promise<void>;
}

declare global {
  interface Window {
    puter: {
      ai: {
        chat: (prompt: string, options: {
          model: string;
          stream?: boolean;
        }) => Promise<any>;
      };
    };
  }
}