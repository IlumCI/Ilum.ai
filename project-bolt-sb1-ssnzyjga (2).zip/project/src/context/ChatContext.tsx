import React, { createContext, useContext, useState, useEffect } from 'react';
import { ChatContextType, Message, Settings } from '../types';
import { aiService } from '../lib/ai';

const defaultSettings: Settings = {
  theme: 'light',
  fontSize: 'base',
  codeTheme: 'github',
};

const ChatContext = createContext<ChatContextType | undefined>(undefined);

export function ChatProvider({ children }: { children: React.ReactNode }) {
  const [messages, setMessages] = useState<Message[]>(() => {
    const saved = localStorage.getItem('chat-messages');
    return saved ? JSON.parse(saved) : [];
  });
  
  const [settings, setSettings] = useState<Settings>(() => {
    const saved = localStorage.getItem('chat-settings');
    return saved ? JSON.parse(saved) : defaultSettings;
  });
  
  const [isLoading, setIsLoading] = useState(false);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    // Initialize AI service when the component mounts
    aiService.initialize().catch(error => {
      console.error('Failed to initialize AI service:', error);
      setError('Failed to initialize AI service. Please refresh the page.');
    });
  }, []);

  useEffect(() => {
    localStorage.setItem('chat-messages', JSON.stringify(messages));
  }, [messages]);

  useEffect(() => {
    localStorage.setItem('chat-settings', JSON.stringify(settings));
    document.documentElement.classList.toggle('dark', settings.theme === 'dark');
  }, [settings]);

  const addMessage = (content: string, role: Message['role']) => {
    const newMessage: Message = {
      id: crypto.randomUUID(),
      content,
      role,
      timestamp: Date.now(),
    };
    setMessages(prev => [...prev, newMessage]);
  };

  const sendMessage = async (content: string) => {
    try {
      setError(null);
      setIsLoading(true);
      addMessage(content, 'user');

      // Create a temporary message for streaming
      const tempId = crypto.randomUUID();
      const tempMessage: Message = {
        id: tempId,
        content: '',
        role: 'assistant',
        timestamp: Date.now(),
      };
      setMessages(prev => [...prev, tempMessage]);

      // Handle streaming updates
      const updateTempMessage = (newContent: string) => {
        setMessages(prev => 
          prev.map(msg => 
            msg.id === tempId 
              ? { ...msg, content: newContent }
              : msg
          )
        );
      };

      // Send message to AI service
      const response = await aiService.sendMessage(content, updateTempMessage);
      
      // Update the temporary message with the final response
      setMessages(prev => 
        prev.map(msg => 
          msg.id === tempId ? response : msg
        )
      );
    } catch (error) {
      console.error('Error sending message:', error);
      const errorMessage = error instanceof Error ? error.message : 'An unexpected error occurred';
      setError(errorMessage);
      
      // Remove the temporary message if it exists
      setMessages(prev => prev.filter(msg => msg.id !== tempId));
      
      // Add error message
      addMessage(
        'Sorry, I encountered an error: ' + errorMessage + '. Please try again.',
        'assistant'
      );
    } finally {
      setIsLoading(false);
    }
  };

  const clearMessages = () => setMessages([]);

  const updateSettings = (newSettings: Partial<Settings>) => {
    setSettings(prev => ({ ...prev, ...newSettings }));
  };

  return (
    <ChatContext.Provider value={{
      messages,
      settings,
      isLoading,
      error,
      addMessage,
      clearMessages,
      updateSettings,
      sendMessage,
    }}>
      {children}
    </ChatContext.Provider>
  );
}

export function useChat() {
  const context = useContext(ChatContext);
  if (!context) {
    throw new Error('useChat must be used within a ChatProvider');
  }
  return context;
}