import React from 'react';
import ReactMarkdown from 'react-markdown';
import { Prism as SyntaxHighlighter } from 'react-syntax-highlighter';
import { oneLight, oneDark } from 'react-syntax-highlighter/dist/esm/styles/prism';
import { Copy, Check, Terminal } from 'lucide-react';
import { Message } from '../types';
import { useChat } from '../context/ChatContext';
import { WebContainerComponent } from './WebContainer';

interface ChatMessageProps {
  message: Message;
}

export function ChatMessage({ message }: ChatMessageProps) {
  const { settings } = useChat();
  const [copied, setCopied] = React.useState(false);
  const [showWebContainer, setShowWebContainer] = React.useState(false);

  const copyCode = (code: string) => {
    navigator.clipboard.writeText(code);
    setCopied(true);
    setTimeout(() => setCopied(false), 2000);
  };

  const handleRunInWebContainer = (code: string) => {
    const files = {
      'index.js': {
        file: {
          contents: code
        }
      }
    };
    setShowWebContainer(true);
  };

  return (
    <div
      className={`flex ${
        message.role === 'user' ? 'justify-end' : 'justify-start'
      } mb-4`}
    >
      <div
        className={`max-w-[80%] rounded-lg p-4 ${
          message.role === 'user'
            ? 'bg-blue-500 text-white'
            : 'bg-gray-100 dark:bg-gray-700 text-gray-800 dark:text-white'
        }`}
      >
        <ReactMarkdown
          className="prose dark:prose-invert max-w-none"
          components={{
            code({ node, inline, className, children, ...props }) {
              const match = /language-(\w+)/.exec(className || '');
              const code = String(children).replace(/\n$/, '');

              if (!inline && match) {
                return (
                  <div className="relative">
                    <div className="absolute top-2 right-2 flex space-x-2">
                      <button
                        onClick={() => copyCode(code)}
                        className="p-1 rounded bg-gray-700/50 hover:bg-gray-700/75 transition-colors"
                        aria-label="Copy code"
                      >
                        {copied ? (
                          <Check className="w-4 h-4 text-green-400" />
                        ) : (
                          <Copy className="w-4 h-4 text-gray-300" />
                        )}
                      </button>
                      <button
                        onClick={() => handleRunInWebContainer(code)}
                        className="p-1 rounded bg-gray-700/50 hover:bg-gray-700/75 transition-colors"
                        aria-label="Run in WebContainer"
                      >
                        <Terminal className="w-4 h-4 text-gray-300" />
                      </button>
                    </div>
                    <SyntaxHighlighter
                      style={settings.codeTheme === 'github' ? oneLight : oneDark}
                      language={match[1]}
                      PreTag="div"
                      {...props}
                    >
                      {code}
                    </SyntaxHighlighter>
                  </div>
                );
              }
              return <code className={className} {...props}>{children}</code>;
            },
          }}
        >
          {message.content}
        </ReactMarkdown>
        {showWebContainer && (
          <div className="mt-4 h-[400px] rounded-lg overflow-hidden border border-gray-200 dark:border-gray-600">
            <WebContainerComponent
              files={{
                'index.js': {
                  file: {
                    contents: message.content
                  }
                }
              }}
              onReady={() => console.log('WebContainer ready')}
            />
          </div>
        )}
      </div>
    </div>
  );
}