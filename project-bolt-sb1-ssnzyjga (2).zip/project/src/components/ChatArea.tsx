import React, { useEffect, useRef } from 'react';
import { useChat } from '../context/ChatContext';
import { ChatMessage } from './ChatMessage';

export function ChatArea() {
  const { messages, settings } = useChat();
  const bottomRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    bottomRef.current?.scrollIntoView({ behavior: 'smooth' });
  }, [messages]);

  return (
    <div className={`flex-1 overflow-y-auto p-4 space-y-4 text-${settings.fontSize}`}>
      {messages.length === 0 ? (
        <div className="flex items-center justify-center h-full text-gray-500 dark:text-gray-400">
          <p>Start a conversation with the AI Dev Assistant</p>
        </div>
      ) : (
        messages.map((message) => (
          <ChatMessage key={message.id} message={message} />
        ))
      )}
      <div ref={bottomRef} />
    </div>
  );
}