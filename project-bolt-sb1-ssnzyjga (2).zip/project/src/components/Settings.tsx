import React from 'react';
import { X, Moon, Sun, Type } from 'lucide-react';
import { useChat } from '../context/ChatContext';

interface SettingsProps {
  isOpen: boolean;
  onClose: () => void;
}

export function Settings({ isOpen, onClose }: SettingsProps) {
  const { settings, updateSettings, clearMessages } = useChat();

  if (!isOpen) return null;

  return (
    <div className="fixed inset-0 bg-black/50 z-50 flex items-center justify-center">
      <div className="bg-white dark:bg-gray-800 rounded-lg shadow-xl max-w-md w-full mx-4">
        <div className="flex items-center justify-between p-4 border-b dark:border-gray-700">
          <h2 className="text-xl font-semibold text-gray-800 dark:text-white">Settings</h2>
          <button
            onClick={onClose}
            className="p-1 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700"
            aria-label="Close settings"
          >
            <X className="w-6 h-6" />
          </button>
        </div>
        
        <div className="p-4 space-y-6">
          <div className="space-y-2">
            <label className="flex items-center justify-between">
              <span className="flex items-center space-x-2">
                {settings.theme === 'dark' ? (
                  <Moon className="w-5 h-5" />
                ) : (
                  <Sun className="w-5 h-5" />
                )}
                <span>Theme</span>
              </span>
              <select
                value={settings.theme}
                onChange={(e) => updateSettings({ theme: e.target.value as 'light' | 'dark' })}
                className="rounded border dark:border-gray-600 bg-white dark:bg-gray-700 px-3 py-1"
              >
                <option value="light">Light</option>
                <option value="dark">Dark</option>
              </select>
            </label>
          </div>

          <div className="space-y-2">
            <label className="flex items-center justify-between">
              <span className="flex items-center space-x-2">
                <Type className="w-5 h-5" />
                <span>Font Size</span>
              </span>
              <select
                value={settings.fontSize}
                onChange={(e) => updateSettings({ fontSize: e.target.value as 'sm' | 'base' | 'lg' })}
                className="rounded border dark:border-gray-600 bg-white dark:bg-gray-700 px-3 py-1"
              >
                <option value="sm">Small</option>
                <option value="base">Medium</option>
                <option value="lg">Large</option>
              </select>
            </label>
          </div>

          <div className="space-y-2">
            <label className="flex items-center justify-between">
              <span>Code Theme</span>
              <select
                value={settings.codeTheme}
                onChange={(e) => updateSettings({ codeTheme: e.target.value as 'github' | 'dracula' })}
                className="rounded border dark:border-gray-600 bg-white dark:bg-gray-700 px-3 py-1"
              >
                <option value="github">GitHub</option>
                <option value="dracula">Dracula</option>
              </select>
            </label>
          </div>

          <button
            onClick={() => {
              if (confirm('Are you sure you want to clear all messages?')) {
                clearMessages();
                onClose();
              }
            }}
            className="w-full py-2 px-4 bg-red-500 text-white rounded hover:bg-red-600 transition-colors"
          >
            Clear Conversation
          </button>
        </div>
      </div>
    </div>
  );
}