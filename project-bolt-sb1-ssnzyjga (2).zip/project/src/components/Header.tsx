import React from 'react';
import { Bot, Settings as SettingsIcon } from 'lucide-react';
import { useChat } from '../context/ChatContext';

interface HeaderProps {
  onOpenSettings: () => void;
}

export function Header({ onOpenSettings }: HeaderProps) {
  const { settings } = useChat();
  
  return (
    <header className="fixed top-0 left-0 right-0 bg-white dark:bg-gray-800 shadow-md z-50">
      <div className="max-w-4xl mx-auto px-4 h-16 flex items-center justify-between">
        <div className="flex items-center space-x-2">
          <Bot className="w-8 h-8 text-blue-500" />
          <h1 className="text-xl font-semibold text-gray-800 dark:text-white">AI Dev Assistant</h1>
        </div>
        <button
          onClick={onOpenSettings}
          className="p-2 rounded-full hover:bg-gray-100 dark:hover:bg-gray-700 transition-colors"
          aria-label="Open settings"
        >
          <SettingsIcon className="w-6 h-6 text-gray-600 dark:text-gray-300" />
        </button>
      </div>
    </header>
  );
}