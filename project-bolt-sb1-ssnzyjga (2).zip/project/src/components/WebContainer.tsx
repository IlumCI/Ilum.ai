import React, { useEffect, useRef, useState } from 'react';
import { WebContainer } from '@webcontainer/api';
import { Terminal } from 'xterm';
import { FitAddon } from 'xterm-addon-fit';
import 'xterm/css/xterm.css';

interface WebContainerProps {
  files: Record<string, { file: { contents: string } } | { directory: Record<string, unknown> }>;
  onReady?: () => void;
}

export function WebContainerComponent({ files, onReady }: WebContainerProps) {
  const terminalRef = useRef<HTMLDivElement>(null);
  const webContainerRef = useRef<WebContainer | null>(null);
  const terminalInstanceRef = useRef<Terminal | null>(null);
  const [error, setError] = useState<string | null>(null);

  useEffect(() => {
    let isMounted = true;

    const initWebContainer = async () => {
      try {
        // Initialize WebContainer
        webContainerRef.current = await WebContainer.boot();
        
        // Mount the files
        await webContainerRef.current.mount(files);

        // Initialize terminal
        const terminal = new Terminal({
          convertEol: true,
          cursorBlink: true,
          fontSize: 14,
          theme: {
            background: '#1a1b26',
            foreground: '#a9b1d6',
          }
        });
        
        const fitAddon = new FitAddon();
        terminal.loadAddon(fitAddon);
        
        if (terminalRef.current) {
          terminal.open(terminalRef.current);
          fitAddon.fit();
        }
        
        terminalInstanceRef.current = terminal;

        // Start a shell process
        const shellProcess = await webContainerRef.current.spawn('jsh', {
          terminal: {
            cols: terminal.cols,
            rows: terminal.rows,
          },
        });

        shellProcess.output.pipeTo(
          new WritableStream({
            write(data) {
              terminal.write(data);
            },
          })
        );

        // Set up input handling
        const input = shellProcess.input.getWriter();
        terminal.onData((data) => {
          input.write(data);
        });

        // Handle window resize
        const handleResize = () => {
          fitAddon.fit();
          shellProcess.resize({
            cols: terminal.cols,
            rows: terminal.rows,
          });
        };

        window.addEventListener('resize', handleResize);
        
        if (isMounted && onReady) {
          onReady();
        }

        return () => {
          window.removeEventListener('resize', handleResize);
          input.close();
          terminal.dispose();
        };
      } catch (error) {
        console.error('Failed to initialize WebContainer:', error);
        setError(error instanceof Error ? error.message : 'Failed to initialize WebContainer');
      }
    };

    initWebContainer();

    return () => {
      isMounted = false;
    };
  }, [files, onReady]);

  if (error) {
    return (
      <div className="flex flex-col h-full items-center justify-center p-4 bg-red-50 dark:bg-red-900/20 rounded-lg">
        <p className="text-red-600 dark:text-red-400 text-center">
          {error}
        </p>
        <p className="text-sm text-red-500 dark:text-red-300 mt-2 text-center">
          Please ensure you're using a supported browser and the application is served over HTTPS.
        </p>
      </div>
    );
  }

  return (
    <div className="flex flex-col h-full">
      <div 
        ref={terminalRef}
        className="flex-1 bg-[#1a1b26] rounded-lg overflow-hidden"
      />
    </div>
  );
}