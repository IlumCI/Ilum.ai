import { Message } from '../types';

export class AIService {
  private static instance: AIService;
  private isInitialized = false;
  private initializationPromise: Promise<void> | null = null;

  private constructor() {}

  public static getInstance(): AIService {
    if (!AIService.instance) {
      AIService.instance = new AIService();
    }
    return AIService.instance;
  }

  private async waitForPuter(): Promise<void> {
    return new Promise<void>((resolve, reject) => {
      if (typeof window.puter !== 'undefined' && 
          typeof window.puter.ai !== 'undefined' && 
          typeof window.puter.ai.chat === 'function') {
        resolve();
        return;
      }

      const script = document.querySelector('script[src="https://js.puter.com/v2/"]');
      if (!script) {
        reject(new Error('Puter.js script not found'));
        return;
      }

      let attempts = 0;
      const maxAttempts = 50; // 5 seconds total
      
      const checkPuter = setInterval(() => {
        attempts++;
        
        if (typeof window.puter !== 'undefined' && 
            typeof window.puter.ai !== 'undefined' && 
            typeof window.puter.ai.chat === 'function') {
          clearInterval(checkPuter);
          resolve();
          return;
        }
        
        if (attempts >= maxAttempts) {
          clearInterval(checkPuter);
          reject(new Error('Puter.js failed to initialize'));
        }
      }, 100);

      script.onerror = () => {
        clearInterval(checkPuter);
        reject(new Error('Failed to load Puter.js script'));
      };
    });
  }

  public async initialize(): Promise<void> {
    if (this.isInitialized) return;
    
    if (!this.initializationPromise) {
      this.initializationPromise = (async () => {
        try {
          await this.waitForPuter();
          this.isInitialized = true;
        } catch (error) {
          this.initializationPromise = null;
          throw error;
        }
      })();
    }

    return this.initializationPromise;
  }

  public async sendMessage(content: string, onUpdate: (text: string) => void): Promise<Message> {
    try {
      await this.initialize();

      const systemPrompt = `\
You are an AI development assistant. Your responses should be helpful, accurate, and focused on software development topics.
When providing code examples:
- Use clear comments
- Follow best practices
- Include error handling
- Consider performance and security

Current conversation: Help the user with their development-related questions.

User: ${content}`;

      const response = await window.puter.ai.chat(systemPrompt, {
        model: 'claude-3-5-sonnet',
        stream: true
      });

      let fullResponse = '';
      
      try {
        for await (const part of response) {
          if (part?.text) {
            fullResponse += part.text;
            onUpdate(fullResponse);
          }
        }
      } catch (streamError) {
        console.error('Streaming error:', streamError);
        throw new Error('Stream interrupted. Please try again.');
      }

      if (!fullResponse) {
        throw new Error('Empty response received');
      }

      return {
        id: crypto.randomUUID(),
        content: fullResponse,
        role: 'assistant',
        timestamp: Date.now()
      };
    } catch (error) {
      console.error('Error in AI response:', error);
      throw new Error(
        error instanceof Error 
          ? error.message 
          : 'Failed to get AI response. Please try again.'
      );
    }
  }
}

export const aiService = AIService.getInstance();