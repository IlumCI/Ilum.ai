/// <reference types="vite/client" />

declare module '@webcontainer/api';
declare module 'xterm';
declare module 'xterm-addon-fit';