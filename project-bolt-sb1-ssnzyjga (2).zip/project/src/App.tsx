import React, { useState } from 'react';
import { ChatProvider } from './context/ChatContext';
import { Header } from './components/Header';
import { ChatArea } from './components/ChatArea';
import { ChatInput } from './components/ChatInput';
import { Settings } from './components/Settings';

function App() {
  const [isSettingsOpen, setIsSettingsOpen] = useState(false);

  return (
    <ChatProvider>
      <div className="min-h-screen bg-gray-50 dark:bg-gray-900 flex flex-col">
        <Header onOpenSettings={() => setIsSettingsOpen(true)} />
        <main className="flex-1 flex flex-col pt-16">
          <ChatArea />
          <ChatInput />
        </main>
        <Settings isOpen={isSettingsOpen} onClose={() => setIsSettingsOpen(false)} />
      </div>
    </ChatProvider>
  );
}

export default App;